This version is used in practice in the drone using the ELP 180 Deg fish-eye camera.

use for example 
	.main -c 0  -e 0.05 -d 1
to run the application, where the arguments -c, -e, and -d mean camera number, exposure time, and debug respectively.
In this case we use video0, exposure time 0.05 (which is actually a scaled time), and �d 1 means debug active such that the result is graphically shown (0 means hide graphical output).

